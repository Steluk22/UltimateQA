﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;

namespace SampleFramework1WIP
{
    internal class QAHomePage : BaseSampleApplicationPage
    {                           //Inheriting Properties from the BaseSampleApplicationPage.cs file
        
        //private IWebDriver driver;
        public QAHomePage(IWebDriver driver) : base(driver) { }
        //The above syntax instantiates (fancy word for creates) the driver from the Inherited driver definition found in BaseSampleApplicationPage.cs file

        //public bool isVisiblesmall => ViewAllButton.Displayed;
        public bool isVisiblesmall
        {
            get
            {
                try
                {
                    return ViewAllButton.Displayed;
                }
                catch (NoSuchElementException)
                {

                    return false;
                }
            }


        }

        public IWebElement ViewAllButton => Driver.FindElement(By.XPath("//*[@class='et_pb_button et_pb_custom_button_icon et_pb_button_0 et_hover_enabled et_pb_bg_layout_light']"));

        internal void waitForPage()
        {
            WebDriverWait wait = new WebDriverWait(Driver, TimeSpan.FromSeconds(20));
            IWebElement element = wait.Until((d) => { return ViewAllButton; });
        }
    }
}

/*
 * The commented code here shows a different implementation that also would have worked
 * When your property will only contain a getter for the foreseeable future you can
 * use the => syntax to shorten your code!
 * It is essentially the same as doing the long
 * Property{get;set;} syntax 
 */
/*
public bool IsVisible 
{ 
get
{
return Driver.Title.Contains("whatever it should say");
}




internal set
{

}

}*/
