﻿using System;
using System.IO;
using System.Reflection;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace SampleFramework1WIP
{
    [TestClass]
    [TestCategory("SampleApplicationOne")]
    public class SampleApplicationOneTests
    {
        //In this early example we will define the webdriver method here on the test case 
        //this is not what you should be doing, ideally we have it live in its own file
        //or maybe on a Main/Common page but for now we will do it here to simplify the procedure
        private IWebDriver Driver { get; set; }
        private TestUser TheTestUser { get; set; }

        private TestUser eContact { get; set; }

        private SampleApplicationpage sampleAppPage { get; set; }

        [TestInitialize]
        public void SetupForEveryTestMethod()
        {
            Driver = GetChromeDriver();
            //if we wanted to use different data for each test case we would not define the TestUser
            //in this way.  We would want to define the class in the testmethod using a shared class with properties
            TheTestUser = new TestUser();
            TheTestUser.FirstName = "Steven";
            TheTestUser.LastName = "Lukander";
            TheTestUser.Gender = GenderType.male;

            eContact = new TestUser();
            eContact.FirstName = "Chyanna";
            eContact.LastName = "Lukander";
            eContact.Gender = GenderType.female;

            sampleAppPage = new SampleApplicationpage(Driver);
            Driver.Manage().Window.Maximize();
        }
        /*
         * The 4 test cases below represent an application following an Agile development lifecycle
         * See that each one adds some small functionality and then tests that it is working
         * If this were a real test suite the final test case would likely be the only test script ran
         * during a regression.  Maybe the third would make it but it would depend
         * on the documentation and decision of the QA manager/team
         * 
         */
        [TestMethod]
        public void TestMethod1()
        {

            //Summary: Go to the application page, enter a first name, and Submit that data.
            var sampleApplicationPage = new SampleApplicationpage(Driver);
            sampleApplicationPage.GoTo();
            var QAHomePage = sampleApplicationPage.FillOutPrimaryContactFormAndSubmit(TheTestUser); 
            QAHomePage.waitForPage();
            Assert.IsTrue(QAHomePage.isVisiblesmall, "Page was not visible or not correct page"); //this always fails because isVisible checks for the sprint 2 page, not sprint 1
        
        }
        [TestMethod]
        public void PretendTestNumber2()
        {
            
            //Summary: Go to the application page, enter a first name,last name and Submit that data.
            var sampleApplicationPage = new SampleApplicationpage(Driver);
            sampleApplicationPage.GoTo();
            var QAHomePage = sampleApplicationPage.FillOutPrimaryContactFormAndSubmit(TheTestUser);
            QAHomePage.waitForPage();
            Assert.IsTrue(QAHomePage.isVisiblesmall, "Page was not visible or not correct page");
            
        }

        [TestMethod]
        [Description("The Description Attribute Allows you to type a short desc. for your test")]//Sort of like comments but more official
        public void Sprint3Test()
        {
            
            //summary: go to sprint 3 page, enter a first name, last name, Gender using radio buttons and submit
            sampleAppPage.GoTo();
            var QAHomePage = sampleAppPage.FillOutPrimaryContactFormAndSubmit(TheTestUser);
            QAHomePage.waitForPage();
            AssertPageVisible(QAHomePage); //for each assertion it will be beneficial to factor it out into its own method
                                           //many tests will reuse this assertion and other types of asserts may be needed later
            
        }

        [TestMethod]
        public void Sprint4Test()
        {
            //summary: go to sprint 3 page, enter a first name, last name, Gender using radio buttons and submit
            sampleAppPage.GoTo();
            sampleAppPage.FillOutEmergencyContactForm(eContact);
            var QAHomePage = sampleAppPage.FillOutPrimaryContactFormAndSubmit(TheTestUser);
            QAHomePage.waitForPage();
            AssertPageVisible(QAHomePage); //for each assertion it will be beneficial to factor it out into its own method
                                           //many tests will reuse this assertion and other types of asserts may be needed later
        }

        private IWebDriver GetChromeDriver()
        {
            var outPutDirectory = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
            //The above statement looks for the directory that your project is in and assigns that path to a //variable 
            return new ChromeDriver(outPutDirectory);
            //ChromeDriver(PATH) will set the path to the chrome driver and make it usable to driver objects 
            //in your code 
        }
        private static void AssertPageVisible(QAHomePage QAHomePage)
        {
            Assert.IsTrue(QAHomePage.isVisiblesmall, "Page was not visible or not correct page");
        }

        [TestCleanup]
        public void CleanUp()
        {
            //These will be optimized later
            Driver.Close();
            Driver.Quit();
        }
    }
}
