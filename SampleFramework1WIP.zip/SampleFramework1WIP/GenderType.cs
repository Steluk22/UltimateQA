﻿namespace SampleFramework1WIP
{
    public enum GenderType
    {
        male,
        female,
        other
    }
}