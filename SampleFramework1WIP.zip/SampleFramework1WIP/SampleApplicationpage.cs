﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using OpenQA.Selenium;
using System;

namespace SampleFramework1WIP
{
    internal class SampleApplicationpage : BaseSampleApplicationPage
    {
        //private IWebDriver Driver { get; set; }
        
        public SampleApplicationpage(IWebDriver driver) : base(driver) { }
        public IWebElement FirstNameField => Driver.FindElement(By.Name("firstname"));
        public IWebElement SubmitButton => Driver.FindElement(By.XPath("//*[@type='submit']"));
        public IWebElement LastNameField => Driver.FindElement(By.Name("lastname"));
        public string PageTitle => "Sample Application Lifecycle - Sprint 4 - Ultimate QA";

        public IWebElement MaleRadio => Driver.FindElement(By.XPath("//*[@value='male']"));

        public IWebElement FemaleRadio => Driver.FindElement(By.XPath("//*[@value='female']"));

        public IWebElement OtherRadio => Driver.FindElement(By.XPath("//*[@value='other']"));

        public IWebElement eFirstNameField => Driver.FindElement(By.Id("f2"));

        public IWebElement eLastNameField => Driver.FindElement(By.Id("l2"));

        public IWebElement eMaleRadio => Driver.FindElement(By.Id("radio2-m"));

        public IWebElement eFemaleRadio => Driver.FindElement(By.Id("radio2-f"));

        public IWebElement eOtherRadio => Driver.FindElement(By.Id("radio2-0"));

        public bool isVisible
        {
            get
            {
                return Driver.Title.Contains(PageTitle);
            }
            internal set { }
        }


        internal void GoTo()
        {
            Driver.Navigate().GoToUrl("https://ultimateqa.com/sample-application-lifecycle-sprint-4/");
            Assert.IsTrue(isVisible);

        }

        internal QAHomePage FillOutEmergencyContactForm(TestUser eContact)
        {
            eFirstNameField.SendKeys(eContact.FirstName);
            eLastNameField.SendKeys(eContact.LastName);
            ClickeGender(eContact.Gender);
            return new QAHomePage(Driver);
        }

        internal QAHomePage FillOutPrimaryContactFormAndSubmit(TestUser user)
        {
            FirstNameField.SendKeys(user.FirstName);
            LastNameField.SendKeys(user.LastName);
            ClickGender(user.Gender);
            SubmitButton.Submit();
            return new QAHomePage(Driver);

        }

        private void ClickGender(GenderType gender)
        {
            switch (gender)
            { 
                case GenderType.male:
                    MaleRadio.Click();
                    break;
                case GenderType.female:
                    FemaleRadio.Click();
                    break;
                case GenderType.other:
                    OtherRadio.Click();
                    break;
            } 
        }

        private void ClickeGender(GenderType eGender)
        {
            switch (eGender)
            {
                case GenderType.male:
                    eMaleRadio.Click();
                    break;
                case GenderType.female:
                    eFemaleRadio.Click();
                    break;
                case GenderType.other:
                    eOtherRadio.Click();
                    break;
            }
        }

    }
}